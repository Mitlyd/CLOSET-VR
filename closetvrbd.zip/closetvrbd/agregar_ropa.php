<?php
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre_prenda'];
    $imagen = $_POST['imagen_url'];
    $link = $_POST['link_prenda'];
    $descripcion = $_POST['descripcion'];

    $sql = "INSERT INTO ropa (nombre_prenda, imagen_url, link_prenda, descripcion) VALUES (?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $nombre, $imagen, $link, $descripcion);

    if ($stmt->execute()) {
        // Redirigir después de agregar
        header("Location: catalogo.php");
        exit();
    } else {
        echo "❌ Error al agregar prenda: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>