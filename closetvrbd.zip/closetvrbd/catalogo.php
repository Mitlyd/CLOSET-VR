<?php
session_start();
include("conexion.php");

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

$sql = "SELECT * FROM ropa";
$resultado = $conn->query($sql);
?>

<h2>Catálogo</h2>

<a href="agregar_prenda.php">
    <button style="padding: 10px 20px; background-color: #4CAF50; color: white; border: none; border-radius: 5px; margin-bottom: 20px;">
        ➕ Agregar nueva prenda
    </button>
</a>

<a href="logout.php">
    <button style="padding: 10px 20px; background-color: #f44336; color: white; border: none; border-radius: 5px; margin-left: 10px;">
        🔒 Cerrar sesión
    </button>
</a>

<?php while($fila = $resultado->fetch_assoc()): ?>
    <div style="border: 1px solid #ccc; padding: 15px; margin-bottom: 10px;">
        <h3><?php echo $fila['nombre_prenda']; ?></h3>
        <img src="<?php echo $fila['imagen_url']; ?>" width="200"><br>
        <p><?php echo $fila['descripcion']; ?></p>
        <a href="<?php echo $fila['link_prenda']; ?>" target="_blank">🛒 Ir a la tienda</a><br><br>
        <form method="POST" action="agregar_favorito.php">
            <input type="hidden" name="prenda_id" value="<?php echo $fila['id']; ?>">
            <button type="submit">❤️ Agregar a favoritos</button>
        </form>
    </div>
<?php endwhile; ?>
