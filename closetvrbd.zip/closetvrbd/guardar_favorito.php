
<?php
session_start();
include("conexion.php");

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$prenda_id = $_POST['prenda_id'];

// Verificamos si ya está en favoritos
$verifica = $conn->prepare("SELECT * FROM favoritos WHERE usuario_id = ? AND prenda_id = ?");
$verifica->bind_param("ii", $usuario_id, $prenda_id);
$verifica->execute();
$resultado = $verifica->get_result();

if ($resultado->num_rows == 0) {
    // Si no existe, se agrega
    $stmt = $conn->prepare("INSERT INTO favoritos (usuario_id, prenda_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $usuario_id, $prenda_id);
    $stmt->execute();
}

header("Location: catalogo.php");
exit;
?>
