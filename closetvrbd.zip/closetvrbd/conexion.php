<?php
$host = "sql.freedb.tech";
$usuario = "freedb_micheelvr";
$contraseña = "?8hkarQUd7Rs?CN";
$base_de_datos = "freedb_closetvrbd";

// Crear la conexión
$conn = new mysqli($host, $usuario, $contraseña, $base_de_datos);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
