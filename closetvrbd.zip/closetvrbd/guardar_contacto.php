<?php
include("conexion.php"); 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $nombre = $_POST["nombre"];
    $correo = $_POST["correo"];
    $telefono = $_POST["telefono"];
    $mensaje = $_POST["mensaje"];

    // Preparar la consulta SQL
    $sql = "INSERT INTO contacto (nombre, correo, telefono, mensaje) 
            VALUES (?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $nombre, $correo, $telefono, $mensaje);

    if ($stmt->execute()) {
        echo "✅ Mensaje enviado correctamente. ¡Gracias por contactarnos!";
    } else {
        echo "❌ Error al guardar el mensaje: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
} else {
    echo "⚠️ Acceso no válido.";
}
?>
