<!-- index.html -->
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Closet VR</title>
</head>
<body>
  <h1>Bienvenido a Closet VR</h1>
  <a href="registro.html">Ir al registro</a>
</body>
</html>
