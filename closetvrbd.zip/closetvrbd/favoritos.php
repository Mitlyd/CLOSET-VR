<?php
session_start();
include("conexion.php");

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

$sql = "SELECT p.nombre_prenda, p.descripcion, p.imagen_url 
        FROM favoritos f
        JOIN prendas p ON f.prenda_id = p.id
        WHERE f.usuario_id = $usuario_id";

$resultado = $conn->query($sql);
?>

<h2>Mis Favoritos</h2>
<?php while($fila = $resultado->fetch_assoc()): ?>
    <div>
        <h3><?php echo $fila['nombre_prenda']; ?></h3>
        <img src="<?php echo $fila['imagen_url']; ?>" width="200">
        <p><?php echo $fila['descripcion']; ?></p>
    </div>
<?php endwhile; ?>